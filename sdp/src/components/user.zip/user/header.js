import React, { Component } from "react";

class Header extends Component {
  render() {
    return (
      <header className="clearfix mt-4">
        <h1></h1>
      </header>
    );
  }
}

export default Header;
